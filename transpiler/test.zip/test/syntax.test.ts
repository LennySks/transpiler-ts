import { compiler } from '../src/ts/compiler'

test('Syntax error for invalid literal', () => {
    const input = 'let x = ' // Invalid literal
    let errorMessage = ''
    try {
        compiler(input)
    } catch (error) {
        errorMessage = error.message
    }
    expect(errorMessage).toBe('Value is undefined')
})

test('throws error on unsupported value type', () => {
    const unsupportedValue = {
        type: 'unsupportedType',
        value: 'someValue'
    }

    expect(() => compiler(unsupportedValue)).toThrow(
        'Unsupported value type: unsupportedType',
    )
})
